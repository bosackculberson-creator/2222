深蓝色树木透明 PNG 素材 · 7 款

参考原图的深蓝色叶冠、灰蓝色层次、细金色枝纹及东方手绘插画质感。
每款为独立生成的不同树形，PNG 均包含透明 Alpha 通道，保留原始分辨率。
01–04、06–07：1254 × 1254 像素；05 古树：1402 × 1122 像素。
preview.jpg 为带浅色底的编号总览；PNG 文件夹中的图片为透明素材。

树形目录：
01 圆冠阔叶 — PNG/01-round-crown.png
02 高挑直立 — PNG/02-tall-slender.png
03 层叠云松 — PNG/03-layered-pine.png
04 垂枝蓝柳 — PNG/04-weeping-willow.png
05 苍劲古树 — PNG/05-ancient-spreading.png
06 双干舒展 — PNG/06-twin-trunk.png
07 迎风斜生 — PNG/07-windswept.png

直接将 PNG 作为图层导入设计软件、视频软件或网页即可使用。

