樱花树透明 PNG 素材 · 10 款

参考原图的粉色樱花、深色树干与东方手绘插画风格。
每款为独立生成的不同树形，PNG 均含透明 Alpha 通道。
单张原始尺寸：1254 × 1254 像素，sRGB。
PNG 文件中的透明区域在部分查看器中可能显示为黑色，叠加到背景后即为透明。
preview.jpg 为带浅色底的编号总览，仅供选图；PNG 文件夹中的图片为透明素材。

树形目录：
01 圆冠盛放 — PNG/01-round-crown.png
02 高挑直立 — PNG/02-tall-slender.png
03 垂枝流苏 — PNG/03-weeping.png
04 左倾舒展 — PNG/04-left-leaning.png
05 右向迎风 — PNG/05-right-windswept.png
06 苍劲古树 — PNG/06-ancient-gnarled.png
07 双干相依 — PNG/07-twin-trunk.png
08 伞形横冠 — PNG/08-umbrella.png
09 疏枝幼树 — PNG/09-young-sparse.png
10 淡紫舒冠 — PNG/10-lavender-spreading.png

建议：直接将 PNG 作为图层导入设计软件、视频软件或网页中使用。

